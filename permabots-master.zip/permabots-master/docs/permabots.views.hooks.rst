permabots.views.hooks package
=============================

Submodules
----------

permabots.views.hooks.kik_hook module
-------------------------------------

.. automodule:: permabots.views.hooks.kik_hook
    :members:
    :undoc-members:
    :show-inheritance:

permabots.views.hooks.messenger_hook module
-------------------------------------------

.. automodule:: permabots.views.hooks.messenger_hook
    :members:
    :undoc-members:
    :show-inheritance:

permabots.views.hooks.permabots_hook module
-------------------------------------------

.. automodule:: permabots.views.hooks.permabots_hook
    :members:
    :undoc-members:
    :show-inheritance:

permabots.views.hooks.telegram_hook module
------------------------------------------

.. automodule:: permabots.views.hooks.telegram_hook
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: permabots.views.hooks
    :members:
    :undoc-members:
    :show-inheritance:
