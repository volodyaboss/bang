from permabots.views.hooks.permabots_hook import PermabotsHookView  # NOQA
from permabots.views.hooks.telegram_hook import TelegramHookView  # NOQA
from permabots.views.hooks.kik_hook import KikHookView  # NOQA
from permabots.views.hooks.messenger_hook import MessengerHookView  # NOQA