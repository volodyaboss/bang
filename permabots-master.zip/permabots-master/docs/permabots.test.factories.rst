permabots.test.factories package
================================

Submodules
----------

permabots.test.factories.bot module
-----------------------------------

.. automodule:: permabots.test.factories.bot
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.handler module
---------------------------------------

.. automodule:: permabots.test.factories.handler
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.hook module
------------------------------------

.. automodule:: permabots.test.factories.hook
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.kik_api module
---------------------------------------

.. automodule:: permabots.test.factories.kik_api
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.kik_lib module
---------------------------------------

.. automodule:: permabots.test.factories.kik_lib
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.messenger_api module
---------------------------------------------

.. automodule:: permabots.test.factories.messenger_api
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.messenger_lib module
---------------------------------------------

.. automodule:: permabots.test.factories.messenger_lib
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.response module
----------------------------------------

.. automodule:: permabots.test.factories.response
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.state module
-------------------------------------

.. automodule:: permabots.test.factories.state
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.telegram_api module
--------------------------------------------

.. automodule:: permabots.test.factories.telegram_api
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.telegram_lib module
--------------------------------------------

.. automodule:: permabots.test.factories.telegram_lib
    :members:
    :undoc-members:
    :show-inheritance:

permabots.test.factories.user module
------------------------------------

.. automodule:: permabots.test.factories.user
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: permabots.test.factories
    :members:
    :undoc-members:
    :show-inheritance:
