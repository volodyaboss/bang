from permabots.views.api.bot import BotList, BotDetail, TelegramBotList, TelegramBotDetail, KikBotList, KikBotDetail, MessengerBotList, MessengerBotDetail  # NOQA
from permabots.views.api.environment_vars import EnvironmentVarList, EnvironmentVarDetail  # NOQA
from permabots.views.api.handler import (HandlerList, HandlerDetail, HeaderParameterDetail, HeaderParameterList,  # NOQA
                                        UrlParameterList, UrlParameterDetail, SourceStateList, SourceStateDetail)  # NOQA
from permabots.views.api.hook import HookList, HookDetail, TelegramRecipientList, TelegramRecipientDetail, KikRecipientList, KikRecipientDetail, MessengerRecipientList, MessengerRecipientDetail  # NOQA
from permabots.views.api.state import StateList, StateDetail, TelegramChatStateList, TelegramChatStateDetail, KikChatStateList, KikChatStateDetail, MessengerChatStateList, MessengerChatStateDetail  # NOQA