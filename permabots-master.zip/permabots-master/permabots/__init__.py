__version__ = '2.2.3'
default_app_config = "permabots.apps.PermabotsAppConfig"